1. Generate an App Password in your Google Account:
Enable 2-Step Verification: If you haven't already, enable 2-Step Verification for your Google account. This is a prerequisite for generating App Passwords.
Go to App Passwords: Navigate to your Google Account Security settings. Look for "App Passwords" under the "How you sign in to Google" section. You might need to sign in again.
Select App and Device: Choose "Mail" as the app and "Other (Custom name)" as the device. You can give it a descriptive name like "Spring Boot Email App."
Generate: Click "Generate." Google will provide you with a 16-character App Password. Copy this password immediately, as it will not be displayed again.
Oops, something went wrong.